package com.example.tema2;

@Entity
public class Review {

    String mark;
    String fullName;

    public Review(String fullName, String mark) {
        this.fullName = fullName;
        this.mark = mark;
    }
}
